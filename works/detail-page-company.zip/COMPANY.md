---
schema: agentcompanies/v1
kind: company
name: 상세페이지 스튜디오
slug: detail-page-studio
description: 제품 이미지와 핵심 문구를 받아 판매용 상세페이지 HTML 원페이지를 생산하는 AI 스튜디오
version: 0.1.0
goals:
  - 입력(제품 이미지 + 핵심 문구 + 콘셉트)에서 검수를 통과한 상세페이지 HTML을 일관되게 생산한다
---

# 상세페이지 스튜디오

제품 정보를 받아 **판매용 상세페이지 HTML 원페이지**를 만드는 6인 조직이다.

## 파이프라인

```
intake → analysis → strategy → design → build → qa_review → published
                                            └ 변경요청 시 문제 단계로 복귀
```

## 조직

| 에이전트 | 담당 단계 | 산출 문서 |
|---|---|---|
| orchestrator | 전 과정 총괄 | — |
| analyst | analysis | `product_brief` |
| strategist | strategy | `strategy`, `page_spec` |
| designer | design | `copy`, `design_tokens` |
| builder | build | `index_html` |
| qa | qa_review | `qa_report` |

## 전 직원 공통 규칙

1. **문서로만 주고받는다.** 이전 단계의 대화가 아니라 이슈 문서(issue documents)를 읽는다.
   `GET /api/issues/{issueId}/documents/{key}` → 작업 → `PUT /api/issues/{issueId}/documents/{key}`
2. **근거 없는 표현 금지.** 입력 자료에 없는 수치·인증·효능을 만들어내지 않는다.
   "1위", "최고", "완벽", "100%" 같은 표현은 명시적 근거가 있을 때만 쓴다.
3. **이미지에서 안 보이는 특징을 지어내지 않는다.** 제품 설명에 근거가 있어야 한다.
4. **한 하트비트에서 실제 작업을 끝낸다.** 계획만 남기고 종료하지 않는다.
5. **끝나면 반드시 코멘트를 남긴다.** 무엇을 했고 다음이 무엇인지 한 문단.
6. **막히면 blocked로 바꾸고 이유와 필요한 것을 적는다.** 조용히 멈추지 않는다.
