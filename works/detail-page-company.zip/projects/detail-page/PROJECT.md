---
kind: project
name: 상세페이지 생산
slug: detail-page
description: 웹앱에서 들어온 상세페이지 생성 요청을 처리하는 프로젝트
owner: orchestrator
---

# 상세페이지 생산

Vercel 웹앱에서 들어온 요청 하나가 이 프로젝트의 이슈 하나가 된다.

- 부모 이슈 = 하나의 상세페이지 요청 (`intake`)
- 자식 이슈 = 각 단계 작업 (analysis / strategy / design / build / qa_review)
- 산출물 = 부모 이슈에 붙는 issue documents

## 요청 이슈 설명 포맷

웹앱 BFF가 아래 형태로 이슈를 만든다.

```markdown
## 입력

- 제품명: {productName}
- 핵심 문구: {keyMessage}
- 콘셉트: {concept}
- 이미지:
  - https://{supabase}/storage/v1/object/public/product-images/...
  - ...

## 요청 출처

webapp job: {jobId}
```
